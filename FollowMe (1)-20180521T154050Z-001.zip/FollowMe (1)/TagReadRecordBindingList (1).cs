﻿using System;

public class TagReadRecordBindingList
{
    public TagReadRecordBindingList()
	{
	}
}
